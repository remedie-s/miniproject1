package com.example.mini.dto;

public class FileUploadResultDto {

}
