package com.example.mini.dto;

public class QnAReveiwForm {

}
