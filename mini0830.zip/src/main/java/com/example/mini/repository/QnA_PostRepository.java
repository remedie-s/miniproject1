package com.example.mini.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.mini.entity.QnA_Post;

public interface QnA_PostRepository extends JpaRepository<QnA_Post, Integer>{
	
	

}
