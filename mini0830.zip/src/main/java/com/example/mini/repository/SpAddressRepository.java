package com.example.mini.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.mini.entity.SpAddress;

public interface SpAddressRepository extends JpaRepository<SpAddress, Long> {

}
