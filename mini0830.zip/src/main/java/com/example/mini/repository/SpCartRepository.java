package com.example.mini.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.mini.entity.SpCart;

public interface SpCartRepository extends JpaRepository<SpCart, Long> {

	

}
