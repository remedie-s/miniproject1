package com.example.mini.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.example.mini.entity.QnA_Review;

public interface QnA_ReviewRepository extends JpaRepository<QnA_Review, Integer> {

}
