package com.example.mini.service;

import org.springframework.stereotype.Service;

@Service
public class SpOrderService {

}
