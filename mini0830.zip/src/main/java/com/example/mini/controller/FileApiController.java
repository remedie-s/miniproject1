package com.example.mini.controller;

import org.springframework.stereotype.Controller;

@Controller
public class FileApiController {
	
	//TODO

}
